import axios from 'axios';

const COMENTARIO_BASE_REST_API_URL = "http://localhost:8081/api/v1/comentarios";

class ComentarioService {
    addComentario(publicacionId, contenido) {
        return axios.post(`${COMENTARIO_BASE_REST_API_URL}/${publicacionId}/comentarios`, { contenido });
    }

    getComentariosByPublicacionId(publicacionId) {
        return axios.get(`${COMENTARIO_BASE_REST_API_URL}/${publicacionId}/comentarios`);
    }
}

export default new ComentarioService();