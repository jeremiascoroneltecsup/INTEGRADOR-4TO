import React from 'react';
import PublicacionList from '../components/Publicacion/ListPublicacionesComponent';

const Home = () => {
  return (
    <div>
      <h1>Bienvenido a la Red Social</h1>
      <PublicacionList />
    </div>
  );
};

export default Home;