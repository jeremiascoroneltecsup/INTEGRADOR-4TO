import React from 'react';
import ListPublicacionesComponent from '../components/Publicacion/ListPublicacionesComponent';

const Publicaciones = () => {
  return (
    <div>
      <ListPublicacionesComponent />
    </div>
  );
};

export default Publicaciones;