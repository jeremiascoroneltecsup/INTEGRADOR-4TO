import React from 'react';
import EditPublicacionComponent from '../components/Publicacion/EditPublicacionComponent';

const EditPublicacion = () => {
  return (
    <div>
      <EditPublicacionComponent />
    </div>
  );
};

export default EditPublicacion;