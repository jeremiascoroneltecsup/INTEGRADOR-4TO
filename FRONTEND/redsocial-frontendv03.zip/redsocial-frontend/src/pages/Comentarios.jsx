import React from 'react';
import AddComentarioComponent from '../components/Comentario/AddComentarioComponent';
import ListComentariosComponent from '../components/Comentario/ListComentariosComponent';

const Comentarios = () => {
  return (
    <div>
      <h1>Comentarios</h1>
      <AddComentarioComponent />
      <ListComentariosComponent />
    </div>
  );
};

export default Comentarios;