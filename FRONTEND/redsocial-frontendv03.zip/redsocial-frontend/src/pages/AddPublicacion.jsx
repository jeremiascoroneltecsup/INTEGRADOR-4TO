import React from 'react';
import AddPublicacionComponent from '../components/Publicacion/AddPublicacionComponent';

const AddPublicacion = () => {
  return (
    <div>
      <AddPublicacionComponent />
    </div>
  );
};

export default AddPublicacion;