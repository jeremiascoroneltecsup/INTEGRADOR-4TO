import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Header from './components/Layout/Header';
import Footer from './components/Layout/Footer';
import Home from './pages/Home';
import Publicaciones from './pages/Publicaciones';
import AddPublicacion from './pages/AddPublicacion';
import EditPublicacion from './pages/EditPublicacion';
import Comentarios from './pages/Comentarios';
import Publicacion from './pages/Publicacion'; // Asegúrate de importar Publicacion

const App = () => {
  return (
    <Router>
      <Header />
      <div className="container">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/publicaciones" element={<Publicaciones />} />
          <Route path="/add-publicacion" element={<AddPublicacion />} />
          <Route path="/edit-publicacion/:id" element={<EditPublicacion />} />
          <Route path="/comentarios" element={<Comentarios />} />
          <Route path="/publicacion/:id" element={<Publicacion />} /> {/* Agrega esta ruta */}
        </Routes>
      </div>
      <Footer />
    </Router>
  );
};

export default App;