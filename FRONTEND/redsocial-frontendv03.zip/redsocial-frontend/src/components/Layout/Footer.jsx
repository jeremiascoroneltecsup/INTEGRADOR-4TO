import React from 'react';

const Footer = () => {
  return (
    <footer className="footer">
      <center><p>&copy; 2023 Red Social. Todos los derechos reservados.</p></center>
    </footer>
  );
};

export default Footer;