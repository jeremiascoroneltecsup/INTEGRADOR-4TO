import React, { useState, useEffect } from 'react';
import comentarioService from '../../services/comentarioService';
import { useNavigate, useParams } from 'react-router';
import { Link } from 'react-router-dom';

export const AddComentarioComponent = () => {
    const [autor, setAutor] = useState('');
    const [contenido, setContenido] = useState('');
    const navigate = useNavigate();
    const { id } = useParams();

    const saveOrUpdateComentario = (e) => {
        e.preventDefault();
        const comentario = { autor, contenido };

        if (id) {
            comentarioService.updateComentario(id, comentario).then(() => {
                navigate('/comentarios');
            }).catch(error => {
                console.log(error);
            });
        } else {
            comentarioService.createComentario(comentario).then(() => {
                navigate('/comentarios');
            }).catch(error => {
                console.log(error);
            });
        }
    };

    useEffect(() => {
        if (id) {
            comentarioService.getComentarioById(id).then(response => {
                setAutor(response.data.autor);
                setContenido(response.data.contenido);
            }).catch(error => {
                console.log(error);
            });
        }
    }, [id]);

    return (
        <div className="container" style={{ marginTop: "80px" }}>
            <div className="row">
                <div className="card col-md-6 offset-md-3 offset-md-3">
                    <h2 className="text-center">{id ? "Actualizar Comentario" : "Nuevo Comentario"}</h2>
                    <div className="card-body">
                        <form>
                            <div className="form-group mb-2">
                                <label className="form-label">Autor:</label>
                                <input
                                    type="text"
                                    placeholder="Escriba el autor"
                                    name="txtAutor"
                                    className="form-control"
                                    value={autor}
                                    onChange={(e) => setAutor(e.target.value)}
                                />
                            </div>
                            <div className="form-group mb-2">
                                <label className="form-label">Contenido:</label>
                                <textarea
                                    placeholder="Escriba el contenido"
                                    name="txtContenido"
                                    className="form-control"
                                    value={contenido}
                                    onChange={(e) => setContenido(e.target.value)}
                                />
                            </div>
                            <button className="btn btn-danger" onClick={saveOrUpdateComentario}>Guardar</button>
                            <Link to="/comentarios" className="btn btn-primary" style={{ marginLeft: "10px" }}>Cancelar</Link>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default AddComentarioComponent;