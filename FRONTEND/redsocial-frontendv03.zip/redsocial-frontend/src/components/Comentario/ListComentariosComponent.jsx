import React, { useEffect, useState } from 'react';
import comentarioService from '../../services/comentarioService';
import { Link } from 'react-router-dom';

export const ListComentariosComponent = () => {
    const [comentarios, setComentarios] = useState([]);

    useEffect(() => {
        listarComentarios();
    }, []);

    const listarComentarios = () => {
        comentarioService.getAllComentarios().then((response) => {
            setComentarios(response.data);
            console.log(response.data);
        }).catch(error => {
            console.log(error);
        });
    };

    const deleteComentario = (comentarioId) => {
        comentarioService.deleteComentario(comentarioId).then(() => {
            listarComentarios();
        }).catch(error => {
            console.log(error);
        });
    };

    return (
        <div className="container" style={{ marginTop: "80px" }}>
            <h2 className="text-center">Listado de Comentarios</h2>
            <Link to="/add-comentario" className="btn btn-primary">Agregar Comentario</Link>
            <table className="table table-secondary table-hover" style={{ marginTop: "20px" }}>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Autor</th>
                        <th>Contenido</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    {comentarios.map(comentario => (
                        <tr key={comentario.id}>
                            <td>{comentario.id}</td>
                            <td>{comentario.autor}</td>
                            <td>{comentario.contenido}</td>
                            <td>
                                <Link className="btn btn-info" to={`/edit-comentario/${comentario.id}`}>Actualizar</Link>
                                <button style={{ marginLeft: "10px" }} className="btn btn-danger" onClick={() => deleteComentario(comentario.id)}>Eliminar</button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default ListComentariosComponent;