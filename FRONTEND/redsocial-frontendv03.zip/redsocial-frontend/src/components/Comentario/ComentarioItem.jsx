import React from 'react';

const ComentarioItem = ({ comentario }) => {
  return (
    <div className="card">
      <div className="card-body">
        <p className="card-text">{comentario.contenido}</p>
      </div>
    </div>
  );
};

export default ComentarioItem;