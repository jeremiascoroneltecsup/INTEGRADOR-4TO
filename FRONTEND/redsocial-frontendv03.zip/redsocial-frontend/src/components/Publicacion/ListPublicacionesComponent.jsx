import React, { useEffect, useState } from 'react';
import publicacionService from '../../services/publicacionService';
import { Link } from 'react-router-dom';

export const ListPublicacionesComponent = () => {
    const [publicaciones, setPublicaciones] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        listarPublicaciones();
    }, []);

    const listarPublicaciones = () => {
        publicacionService.getAllPublicaciones()
            .then(response => {
                console.log('Respuesta de la API:', response.data); // Verifica la respuesta de la API
                // Asegúrate de que response.data es un array
                if (Array.isArray(response.data)) {
                    setPublicaciones(response.data);
                } else {
                    setError('La respuesta del servicio no es un array');
                }
            })
            .catch(error => {
                setError('Error al obtener las publicaciones');
                console.log(error);
            })
            .finally(() => {
                setLoading(false);
            });
    };

    const deletePublicacion = (publicacionId) => {
        publicacionService.deletePublicacion(publicacionId)
            .then(() => {
                listarPublicaciones();
            })
            .catch(error => {
                setError('Error al eliminar la publicación');
                console.log(error);
            });
    };

    if (loading) {
        return <div>Cargando...</div>;
    }

    if (error) {
        return <div>Error: {error}</div>;
    }

    if (!Array.isArray(publicaciones)) {
        return <div>Error: La respuesta del servicio no es un array</div>;
    }

    return (
        <div className='container' style={{ marginTop: "80px" }}>
            <h2 className='text-center'>Listado de Publicaciones</h2>
            <div className='d-flex justify-content-between align-items-center mb-4'>
                <Link to='/add-publicacion' className='btn btn-primary'>Agregar Publicación</Link>
            </div>
            <div className='row'>
                {publicaciones.map(publicacion => (
                    <div key={publicacion.id} className='col-md-12 mb-4'>
                        <div className='card' style={{ height: '500px', display: 'flex', flexDirection: 'column' }}>
                            <div className='card-body'>
                                <h5 className='card-title'>{publicacion.titulo}</h5>
                                <p className='card-text'>{publicacion.contenido}</p>
                                {publicacion.imagenUrl && <img src={publicacion.imagenUrl} alt={publicacion.titulo} className="img-fluid" style={{ maxHeight: '300px', objectFit: 'cover', width: '100%', display: 'block', margin: '0 auto' }} />}
                                <div className='d-flex justify-content-between mt-3'>
                                    <Link to={`/edit-publicacion/${publicacion.id}`} className='btn btn-info'>Actualizar</Link>
                                    <button className='btn btn-danger' onClick={() => deletePublicacion(publicacion.id)}>Eliminar</button>
                                </div>
                                <div className='comentarios-section mt-3'>
                                    <Link to={`/publicacion/${publicacion.id}`} className='btn btn-primary'>Comentar</Link>
                                </div>
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default ListPublicacionesComponent;