import React, { useEffect, useState } from 'react';
import PublicacionService from '../services/PublicacionService';
import { Link } from 'react-router-dom';

export const ListPublicacionesComponent = () => {
    const [publicaciones, setPublicaciones] = useState([]);
    const [error, setError] = useState(null);

    useEffect(() => {
        listarPublicaciones();
    }, []);

    const listarPublicaciones = () => {
        PublicacionService.getAllPublicaciones()
            .then(response => {
                setPublicaciones(response.data);
                setError(null);
            })
            .catch(error => {
                console.log(error);
                setError("Error al cargar las publicaciones.");
            });
    };

    const deletePublicacion = (publicacionId) => {
        PublicacionService.deletePublicacion(publicacionId)
            .then(() => listarPublicaciones())
            .catch(error => {
                console.log(error);
                setError("Error al eliminar la publicación.");
            });
    };

    return (
        <div className='container' style={{ marginTop: "80px" }}>
            <h2 className='text-center'>Listado de Publicaciones</h2>
            <Link to='/add-publicacion' className='btn btn-primary mb-3'>Agregar Publicación</Link>
            
            {error && <p className='text-danger'>{error}</p>}
            
            <table className="table table-secondary table-hover" style={{ marginTop: "20px" }}>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Título</th>
                        <th>Contenido</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    {publicaciones.map(publicacion => (
                        <tr key={publicacion.id}>
                            <td>{publicacion.id}</td>
                            <td>{publicacion.titulo}</td>
                            <td>{publicacion.contenido}</td>
                            <td>
                                <Link className='btn btn-info me-2' to={`/edit-publicacion/${publicacion.id}`}>Actualizar</Link>
                                <button className='btn btn-danger' onClick={() => deletePublicacion(publicacion.id)}>Eliminar</button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default ListPublicacionesComponent;
