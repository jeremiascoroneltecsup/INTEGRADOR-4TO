import React, { useState, useEffect } from 'react';
import PublicacionService from '../services/PublicacionService';
import { useNavigate, useParams } from 'react-router';
import { Link } from 'react-router-dom';

export const AddPublicacionComponent = () => {
    const [titulo, setTitulo] = useState('');
    const [contenido, setContenido] = useState('');
    const [error, setError] = useState(null);
    const navigate = useNavigate();
    const { id } = useParams();

    const saveOrUpdatePublicacion = (e) => {
        e.preventDefault();
        const publicacion = { titulo, contenido };

        if (id) {
            PublicacionService.updatePublicacion(id, publicacion)
                .then(() => {
                    navigate('/publicaciones');
                })
                .catch(error => {
                    console.log(error);
                    setError("Error al actualizar la publicación.");
                });
        } else {
            PublicacionService.createPublicacion(publicacion)
                .then(() => {
                    navigate('/publicaciones');
                })
                .catch(error => {
                    console.log(error);
                    setError("Error al crear la publicación.");
                });
        }
    };

    useEffect(() => {
        if (id) {
            PublicacionService.getPublicacionById(id)
                .then(response => {
                    setTitulo(response.data.titulo);
                    setContenido(response.data.contenido);
                })
                .catch(error => {
                    console.log(error);
                    setError("Error al cargar los datos de la publicación.");
                });
        }
    }, [id]);

    return (
        <div className='container' style={{ marginTop: "80px" }}>
            <div className='row'>
                <div className='card col-md-6 offset-md-3'>
                    <h2 className='text-center'>{id ? 'Actualizar Publicación' : 'Nueva Publicación'}</h2>
                    <div className='card-body'>
                        {error && <p className='text-danger'>{error}</p>}
                        <form onSubmit={saveOrUpdatePublicacion}>
                            <div className='form-group mb-2'>
                                <label className='form-label'>Título:</label>
                                <input
                                    type='text'
                                    placeholder='Escriba el título'
                                    name='titulo'
                                    className='form-control'
                                    value={titulo}
                                    onChange={(e) => setTitulo(e.target.value)}
                                    required
                                />
                            </div>
                            <div className='form-group mb-2'>
                                <label className='form-label'>Contenido:</label>
                                <textarea
                                    placeholder='Escriba el contenido'
                                    name='contenido'
                                    className='form-control'
                                    value={contenido}
                                    onChange={(e) => setContenido(e.target.value)}
                                    required
                                />
                            </div>
                            <button type='submit' className='btn btn-danger'>Guardar</button>
                            <Link to='/publicaciones' className='btn btn-primary ms-2'>Cancelar</Link>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default AddPublicacionComponent;
