import React, { useState, useEffect } from 'react';
import { Bell, Home, MessageCircle, Search, Settings, Users } from 'lucide-react';
import ComentarioService from '../services/ComentarioService';
import PublicacionService from '../services/PublicacionService';

export default function ImprovedSocialPlatform() {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState('home');
  const [posts, setPosts] = useState([]);
  const [comments, setComments] = useState([]);

  useEffect(() => {
    // Llamada para obtener publicaciones al cargar el componente
    PublicacionService.getAllPublicaciones()
      .then(response => setPosts(response.data))
      .catch(error => console.error("Error al obtener publicaciones:", error));

    // Llamada para obtener comentarios al cargar el componente
    ComentarioService.getAllComentarios()
      .then(response => setComments(response.data))
      .catch(error => console.error("Error al obtener comentarios:", error));
  }, []);

  return (
    <div className="min-h-screen bg-gray-900 text-white flex flex-col">
      <header className="p-4 flex justify-between items-center">
        <div className="flex items-center">
          <Search size={24} className="mr-2" />
          <input
            type="text"
            placeholder="Buscar"
            className="bg-gray-800 text-white rounded-lg p-2"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <div className="flex items-center">
          <Bell size={24} className="mr-4" />
          <Settings size={24} />
        </div>
      </header>
      <nav className="p-4 flex justify-center space-x-4">
        <button onClick={() => setActiveTab('home')} className={`${activeTab === 'home' ? 'text-blue-500' : ''}`}>
          <Home size={24} />
        </button>
        <button onClick={() => setActiveTab('messages')} className={`${activeTab === 'messages' ? 'text-blue-500' : ''}`}>
          <MessageCircle size={24} />
        </button>
        <button onClick={() => setActiveTab('friends')} className={`${activeTab === 'friends' ? 'text-blue-500' : ''}`}>
          <Users size={24} />
        </button>
      </nav>
      <main className="p-4 flex-grow">
        {activeTab === 'home' && (
          <div>
            <h2 className="text-2xl mb-4">Publicaciones</h2>
            <ul>
              {posts.map(post => (
                <li key={post.id} className="bg-gray-800 p-4 rounded-lg mb-4">
                  <h3 className="text-lg">{post.titulo}</h3>
                  <p>{post.contenido}</p>
                </li>
              ))}
            </ul>
          </div>
        )}
        {activeTab === 'messages' && (
          <div>
            <h2 className="text-2xl mb-4">Comentarios</h2>
            <ul>
              {comments.map(comment => (
                <li key={comment.id} className="bg-gray-800 p-4 rounded-lg mb-4">
                  <p>{comment.contenido}</p>
                </li>
              ))}
            </ul>
          </div>
        )}
        {activeTab === 'friends' && (
          <div>
            <h2 className="text-2xl mb-4">Amigos</h2>
            {/* Aquí puedes agregar la lógica para mostrar la lista de amigos */}
          </div>
        )}
      </main>
    </div>
  );
}