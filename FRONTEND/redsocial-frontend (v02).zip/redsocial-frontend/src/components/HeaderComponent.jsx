import React from 'react';

import { Search, Bell, Users, Settings } from 'lucide-react';

function HeaderComponent() {
    return (
        <header className="bg-white shadow-md py-4 px-6 flex justify-between items-center">
            <h1 className="text-2xl font-bold text-blue-500">Improved Social Platform</h1>
            <div className="flex items-center space-x-4">
                <Search className="w-6 h-6 text-gray-600" />
                <Bell className="w-6 h-6 text-gray-600" />
                <Users className="w-6 h-6 text-gray-600" />
                <Settings className="w-6 h-6 text-gray-600" />
            </div>
        </header>
    );
}

export default HeaderComponent;
