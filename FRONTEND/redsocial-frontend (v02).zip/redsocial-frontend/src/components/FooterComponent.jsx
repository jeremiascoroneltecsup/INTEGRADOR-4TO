import React from 'react';

const FooterComponent = () => {
  return (
    <div className="footer">
      <p>Meta © 2023 - @Vinty_Dawrani</p>
      <p>Privacy Terms Advertising Cookies More</p>
    </div>
  );
};

export default FooterComponent;