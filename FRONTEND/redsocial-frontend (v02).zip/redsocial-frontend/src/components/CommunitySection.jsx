import React from 'react';

const CommunitySection = () => {
  return (
    <div className="sidebar-section">
      <h2>Tus grupos</h2>
      <ul className="group-list">
        <li>nombre_grupo</li>
        <li>nombre_grupo</li>
        <li>nombre_grupo</li>
      </ul>
      <button className="btn-create">+ Crear Nueva Comunidad</button>
    </div>
  );
};

export default CommunitySection;
