import React from 'react';

const EventSection = () => {
  return (
    <div className="sidebar-section">
      <h2>Eventos</h2>
      <div className="event-item">
        <h3>Organizador_evento</h3>
        <p>Descripción del evento</p>
      </div>
      <div className="event-item">
        <h3>NYTIMESCOM</h3>
        <p>Small Bedroom Ideas: The Best Ways to Maximize Your Tiny Space</p>
      </div>
    </div>
  );
};

export default EventSection;
