import React, { useState, useEffect } from 'react';
import ComentarioService from '../services/ComentarioService';
import { useNavigate, useParams } from 'react-router';
import { Link } from 'react-router-dom';

export const AddComentarioComponent = () => {
    const [autor, setAutor] = useState('');
    const [contenido, setContenido] = useState('');
    const [error, setError] = useState(null);
    const navigate = useNavigate();
    const { id } = useParams();

    const saveOrUpdateComentario = (e) => {
        e.preventDefault();
        const comentario = { autor, contenido };

        if (id) {
            ComentarioService.updateComentario(id, comentario)
                .then(() => {
                    navigate('/comentarios');
                })
                .catch(error => {
                    console.log(error);
                    setError("Error al actualizar el comentario.");
                });
        } else {
            ComentarioService.createComentario(comentario)
                .then(() => {
                    navigate('/comentarios');
                })
                .catch(error => {
                    console.log(error);
                    setError("Error al crear el comentario.");
                });
        }
    };

    useEffect(() => {
        if (id) {
            ComentarioService.getComentarioById(id)
                .then(response => {
                    setAutor(response.data.autor);
                    setContenido(response.data.contenido);
                })
                .catch(error => {
                    console.log(error);
                    setError("Error al cargar los datos del comentario.");
                });
        }
    }, [id]);

    return (
        <div className="container" style={{ marginTop: "80px" }}>
            <div className="row">
                <div className="card col-md-6 offset-md-3">
                    <h2 className="text-center">{id ? "Actualizar Comentario" : "Nuevo Comentario"}</h2>
                    <div className="card-body">
                        {/* Muestra el mensaje de error si existe */}
                        {error && <p className="text-danger">{error}</p>}
                        <form onSubmit={saveOrUpdateComentario}>
                            <div className="form-group mb-2">
                                <label className="form-label">Autor:</label>
                                <input
                                    type="text"
                                    placeholder="Escriba el nombre del autor"
                                    name="txtAutor"
                                    className="form-control"
                                    value={autor}
                                    onChange={(e) => setAutor(e.target.value)}
                                    required
                                />
                            </div>
                            <div className="form-group mb-2">
                                <label className="form-label">Contenido:</label>
                                <textarea
                                    placeholder="Escriba el contenido"
                                    name="txtContenido"
                                    className="form-control"
                                    value={contenido}
                                    onChange={(e) => setContenido(e.target.value)}
                                    required
                                />
                            </div>
                            <button type="submit" className="btn btn-danger">Guardar</button>
                            <Link to="/comentarios" className="btn btn-primary ms-2">Cancelar</Link>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default AddComentarioComponent;
