import React, { useEffect, useState } from 'react';
import ComentarioService from '../services/ComentarioService';
import { Link } from 'react-router-dom';

export const ListComentariosComponent = () => {
    const [comentarios, setComentarios] = useState([]);
    const [error, setError] = useState(null);

    useEffect(() => {
        listarComentarios();
    }, []);

    const listarComentarios = () => {
        ComentarioService.getAllComentarios()
            .then((response) => {
                setComentarios(response.data);
                setError(null);
            })
            .catch(error => {
                console.log(error);
                setError("Error al cargar los comentarios.");
            });
    };

    const deleteComentario = (comentarioId) => {
        ComentarioService.deleteComentario(comentarioId)
            .then(() => listarComentarios())
            .catch(error => {
                console.log(error);
                setError("Error al eliminar el comentario.");
            });
    };

    return (
        <div className="container" style={{ marginTop: "80px" }}>
            <h2 className="text-center">Listado de Comentarios</h2>
            <Link to="/add-comentario" className="btn btn-primary mb-3">Agregar Comentario</Link>
            
            {error && <p className="text-danger">{error}</p>}
            
            <table className="table table-secondary table-hover" style={{ marginTop: "20px" }}>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Autor</th>
                        <th>Contenido</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    {comentarios.map(comentario => (
                        <tr key={comentario.id}>
                            <td>{comentario.id}</td>
                            <td>{comentario.autor}</td>
                            <td>{comentario.contenido}</td>
                            <td>
                                <Link className="btn btn-info me-2" to={`/edit-comentario/${comentario.id}`}>Actualizar</Link>
                                <button className="btn btn-danger" onClick={() => deleteComentario(comentario.id)}>Eliminar</button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default ListComentariosComponent;
