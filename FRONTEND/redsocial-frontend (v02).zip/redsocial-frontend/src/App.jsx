import React from 'react';
import './App.css';
import HeaderComponent from './components/HeaderComponent.jsx';
import FooterComponent from './components/FooterComponent.jsx';
import CommunitySection from './components/CommunitySection';
import EventSection from './components/EventSection';
import ListPublicacionesComponent from './components/ListPublicacionesComponent';
import ListComentariosComponent from './components/ListComentariosComponent';
import ImprovedSocialPlatform from './components/ImprovedSocialPlatform';
import AddPublicacionComponent from './components/AddPublicacionComponent.jsx';
import AddComentarioComponent from './components/AddComentarioComponent.jsx';
import { BrowserRouter, Routes, Route } from 'react-router-dom';

function App() {
  return (
    <div>
      <BrowserRouter>
        <HeaderComponent />
        <div className='container'>
          <div className="row">
            {/* Sidebar for Communities */}
            <div className="col-md-3 sidebar">
              <CommunitySection />
            </div>

            {/* Main Content for Publicaciones */}
            <div className="col-md-6">
              <ListPublicacionesComponent />
            </div>

            {/* Sidebar for Events */}
            <div className="col-md-3 events-sidebar">
              <EventSection />
            </div>
          </div>

          {/* Rutas de la aplicación */}
          <Routes>
            {/* Rutas para las publicaciones */}
            <Route exact path='/' element={<ListPublicacionesComponent />} />
            <Route path='/publicaciones' element={<ListPublicacionesComponent />} />
            <Route path='/add-publicacion' element={<AddPublicacionComponent />} />
            <Route path='/edit-publicacion/:id' element={<AddPublicacionComponent />} />

            {/* Rutas para los comentarios */}
            <Route path='/comentarios' element={<ListComentariosComponent />} />
            <Route path='/add-comentario' element={<AddComentarioComponent />} />
            <Route path='/edit-comentario/:id' element={<AddComentarioComponent />} />

            {/* Ruta para ImprovedSocialPlatform */}
            <Route path='/social-platform' element={<ImprovedSocialPlatform />} />
          </Routes>
        </div>
        <FooterComponent />
      </BrowserRouter>
    </div>
  );
}

export default App;