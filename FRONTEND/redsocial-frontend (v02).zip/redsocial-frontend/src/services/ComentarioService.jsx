import axios from 'axios';

const COMENTARIO_BASE_REST_API_URL = "http://localhost:8081/api/v1/comentarios";

class ComentarioService {
    getAllComentarios() {
        return axios.get(COMENTARIO_BASE_REST_API_URL);
    }

    createComentario(comentario) {
        return axios.post(COMENTARIO_BASE_REST_API_URL, comentario);
    }

    getComentarioById(comentarioId) {
        return axios.get(`${COMENTARIO_BASE_REST_API_URL}/${comentarioId}`);
    }

    updateComentario(comentarioId, comentario) {
        return axios.put(`${COMENTARIO_BASE_REST_API_URL}/${comentarioId}`, comentario);
    }

    deleteComentario(comentarioId) {
        return axios.delete(`${COMENTARIO_BASE_REST_API_URL}/${comentarioId}`);
    }
}

export default new ComentarioService();
