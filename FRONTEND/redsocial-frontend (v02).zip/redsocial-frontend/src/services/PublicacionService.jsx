import axios from 'axios';

const PUBLICACION_BASE_REST_API_URL = "http://localhost:8081/api/v1/publicaciones";

class PublicacionService {
    getAllPublicaciones() {
        return axios.get(PUBLICACION_BASE_REST_API_URL);
    }

    createPublicacion(publicacion) {
        return axios.post(PUBLICACION_BASE_REST_API_URL, publicacion);
    }

    getPublicacionById(publicacionId) {
        return axios.get(`${PUBLICACION_BASE_REST_API_URL}/${publicacionId}`);
    }

    updatePublicacion(publicacionId, publicacion) {
        return axios.put(`${PUBLICACION_BASE_REST_API_URL}/${publicacionId}`, publicacion);
    }

    deletePublicacion(publicacionId) {
        return axios.delete(`${PUBLICACION_BASE_REST_API_URL}/${publicacionId}`);
    }
}

export default new PublicacionService();
