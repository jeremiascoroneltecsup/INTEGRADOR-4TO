package com.redsocial.service.Impl;

import com.redsocial.model.Comentario;
import com.redsocial.model.Publicacion;
import com.redsocial.repository.ComentarioRepository;
import com.redsocial.repository.PublicacionRepository;
import com.redsocial.service.ComentarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ComentarioServiceImpl implements ComentarioService {

    @Autowired
    private PublicacionRepository publicacionRepository;

    @Autowired
    private ComentarioRepository comentarioRepository;

    @Override
    public Comentario agregarComentario(Long publicacionId, String contenido) {
        Publicacion publicacion = publicacionRepository.findById(publicacionId).orElse(null);
        if (publicacion != null) {
            Comentario comentario = new Comentario();
            comentario.setContenido(contenido);
            comentario.setPublicacion(publicacion);
            return comentarioRepository.save(comentario);
        }
        return null;
    }

    @Override
    public void eliminarComentario(Long publicacionId, Long comentarioId) {
        Publicacion publicacion = publicacionRepository.findById(publicacionId).orElse(null);
        if (publicacion != null) {
            comentarioRepository.deleteById(comentarioId);
        }
    }

    @Override
    public Comentario actualizarComentario(Long publicacionId, Long comentarioId, String contenido) {
        Publicacion publicacion = publicacionRepository.findById(publicacionId).orElse(null);
        if (publicacion != null) {
            Comentario comentario = comentarioRepository.findById(comentarioId).orElse(null);
            if (comentario != null) {
                comentario.setContenido(contenido);
                return comentarioRepository.save(comentario);
            }
        }
        return null;
    }
}