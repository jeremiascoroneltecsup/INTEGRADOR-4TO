package com.redsocial.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "comentarios")
public class Comentario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "contenido")
    private String contenido;

    // Relación con Publicacion (Many-to-One)
    @ManyToOne
    @JoinColumn(name = "publicacion_id") // Esta columna se usará para la relación
    private Publicacion publicacion;
}