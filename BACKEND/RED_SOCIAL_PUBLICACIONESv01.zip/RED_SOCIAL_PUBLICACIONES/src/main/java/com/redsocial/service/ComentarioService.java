package com.redsocial.service;

import com.redsocial.model.Comentario;

public interface ComentarioService {
    Comentario agregarComentario(Long publicacionId, String contenido);
    void eliminarComentario(Long publicacionId, Long comentarioId);
    Comentario actualizarComentario(Long publicacionId, Long comentarioId, String contenido);
}