package com.redsocial;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RedSocialPublicacionesApplication {

    public static void main(String[] args) {
        SpringApplication.run(RedSocialPublicacionesApplication.class, args);
    }

}
