package com.redsocial.controller;

import com.redsocial.model.Comentario;
import com.redsocial.service.ComentarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/comentarios")
@CrossOrigin(origins = "http://localhost:3000")  // Permite el acceso desde el frontend en React
public class ComentarioController {

    @Autowired
    private ComentarioService comentarioService;

    // Agregar un comentario a una publicación
    @PostMapping("/{publicacionId}/comentarios")
    public ResponseEntity<Comentario> agregarComentario(
            @PathVariable Long publicacionId,
            @RequestParam("contenido") String contenido) {
        Comentario comentario = comentarioService.agregarComentario(publicacionId, contenido);
        return new ResponseEntity<>(comentario, HttpStatus.CREATED);
    }

    // Eliminar un comentario de una publicación
    @DeleteMapping("/{publicacionId}/comentarios/{comentarioId}")
    public ResponseEntity<Void> eliminarComentario(
            @PathVariable Long publicacionId,
            @PathVariable Long comentarioId) {
        comentarioService.eliminarComentario(publicacionId, comentarioId);
        return ResponseEntity.noContent().build();
    }

    // Actualizar un comentario de una publicación
    @PutMapping("/{publicacionId}/comentarios/{comentarioId}")
    public ResponseEntity<Comentario> actualizarComentario(
            @PathVariable Long publicacionId,
            @PathVariable Long comentarioId,
            @RequestParam("contenido") String contenido) {
        Comentario comentario = comentarioService.actualizarComentario(publicacionId, comentarioId, contenido);
        return ResponseEntity.ok(comentario);
    }
}