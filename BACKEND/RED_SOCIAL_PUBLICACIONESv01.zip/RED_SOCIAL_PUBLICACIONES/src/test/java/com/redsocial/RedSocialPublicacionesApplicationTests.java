package com.redsocial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RedSocialPublicacionesApplicationTests {

    @Test
    void contextLoads() {
    }

}
